/**
 * 
 */
/**
 * 
 */
module Training {
}