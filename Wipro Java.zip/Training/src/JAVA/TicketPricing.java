package JAVA;
	import java.util.Scanner;

	public class TicketPricing {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.print("Enter your age: ");
	        int age = sc.nextInt();
	        
	        System.out.print("Enter the type of movie (regular or 3d): ");
	        String movieType = sc.next();
	        
	        double ticketPrice = 0;
	        
	        if(movieType.equalsIgnoreCase("regular")) {
	            if(age < 18) {
	                ticketPrice = 8;
	            } else {
	                ticketPrice = 12;
	            }
	        } else if(movieType.equalsIgnoreCase("3d")) {
	            if(age < 18) {
	                ticketPrice = 10;
	            } else {
	                ticketPrice = 15;
	            }
	        } else {
	            System.out.println("Invalid movie type entered.");
	            return;
	        }
	        
	        System.out.println("Ticket price: $" + ticketPrice);
	        
	        sc.close();
	    }
	}
